#!/usr/bin/env python3
########################################################################
# Filename    : Blink.py
# Description : Make an led blinking.
# auther      : www.freenove.com
# modification: 2018/08/04
########################################################################

def Hello():
	print('Hello World!')

Hello()
